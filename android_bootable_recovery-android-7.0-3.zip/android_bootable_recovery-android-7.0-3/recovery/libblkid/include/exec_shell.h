extern void __attribute__((__noreturn__)) exec_shell(void);
