#ifndef UTIL_LINUX_PAGER
#define UTIL_LINUX_PAGER

void setup_pager(void);

#endif
